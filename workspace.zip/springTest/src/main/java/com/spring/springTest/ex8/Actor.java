package com.spring.springTest.ex8;

public interface Actor {
	public void casting();
}
