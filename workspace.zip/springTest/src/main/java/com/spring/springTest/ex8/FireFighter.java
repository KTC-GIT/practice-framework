package com.spring.springTest.ex8;

public class FireFighter implements Actor {

	@Override
	public void casting() {
		System.out.println("소방관 역할로 불을 끄거나 환자를 구조합니다.");

	}

}
