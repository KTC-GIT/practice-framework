package com.spring.springTest.ex8;

public class Policeman implements Actor {

	@Override
	public void casting() {
		System.out.println("경찰관 역할로 범인을 잡습니다.");

	}

}
