package com.spring.springTest.junit;

import org.aspectj.lang.annotation.Before;

public class Calculator {
	
	public int sum(int a, int b) {
		return a + b;
	}
}
