package com.spring.springTest.ex8;

public class Doctor implements Actor {

	@Override
	public void casting() {
		System.out.println("의사역할로 환자를 진료합니다.");

	}

}
