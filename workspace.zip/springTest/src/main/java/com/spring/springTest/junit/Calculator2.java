package com.spring.springTest.junit;

public class Calculator2 {
	public int div(int a, int b) {
		return a / b;
	}
}
