package com.spring.cjs200810.dao;

public interface StudyDao {
	
}
