package com.spring.cjs200810.service;


public interface StudyService {

	public void getCalendar();
	
}
